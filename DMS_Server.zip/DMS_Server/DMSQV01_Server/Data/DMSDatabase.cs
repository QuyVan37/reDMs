﻿using Microsoft.EntityFrameworkCore;

namespace DMSQV01_Server.Data
{
    public class DMSDatabase : DbContext
    {
        protected readonly IConfiguration Configuration;

        public DMSDatabase(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(Configuration.GetConnectionString("postgresDMS_DATABASe"));
        }

       

    }
}
