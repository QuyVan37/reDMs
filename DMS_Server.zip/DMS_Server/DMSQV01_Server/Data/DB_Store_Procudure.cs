﻿using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System;
using System.Data.Common;
using System.Security.Cryptography.X509Certificates;
namespace DMSQV01_Server.Data
{

    public class DB_Store_Procudure
    {

        //START*** Cấu hình kết nối đến Postgress **//
        string connectionString = "Host=localhost;Username=postgres;Password=sa;Database=DMS";



        private List<Dictionary<string, object>> GetDataFromDatabase(string sql)
        {

            List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(reader.GetName(i), reader.GetValue(i));
                            }
                            data.Add(row);
                        }
                    }
                }
            }
            return data;
        }


        private DbConnection GetConnection()
        {

            var connection = new NpgsqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        //END*** Cấu hình kết nối đến Postgress **//

        public List<Dictionary<string, object>> ExistUser(string code, string password)
        {
            string sql = $"SELECT CASE WHEN EXISTS ( SELECT 1  FROM schemas_users.users u WHERE user_code = '{code}' and password = '{password}')" +
                $"THEN (SELECT u.user_id FROM schemas_users.users u WHERE user_code = '{code}' and password = '{password}') ELSE 0 END AS result;";

            var isExist = GetDataFromDatabase(sql);
            // nếu ko tồn tại thì return 0, nếu tồn tại user thì return user_id
            return isExist;
        }

        public object getUserProfile(int user_id)
        {
            string sql = $"SELECT * FROM schemas_users.users where user_id = {user_id}";

            var user = GetDataFromDatabase(sql);
            return user;
        }


    }
}

