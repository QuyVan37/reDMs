﻿using DMSQV01_Server.Data;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using Microsoft.AspNetCore.SignalR;
using Microsoft.AspNetCore.Http;

namespace DMSQV01_Server.Controllers
{
    public class authorization : Controller
    {
        DB_Store_Procudure db = new DB_Store_Procudure();
        public IActionResult Index()
        {
            return View();
        }


        public async Task<JsonResult> api_login(string code, string password)
        {
            bool status = false;
            var checkUser = (List<Dictionary<string, object>>)db.ExistUser(code, password);
            var user_id = (int)checkUser[0].Values.ToList()[0];

            if (user_id > 0) // có tồn tại user này rồi
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, code)
                };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
                status = true;
                HttpContext.Session.SetString("user_id", user_id.ToString());
                 var isCookiePresent = Request.Cookies.ToList();
            }
            var output = new
            {
                status = status,
                user = api_getUserProfile(user_id),
            };
            return Json(output);
        }



        public async Task<ContentResult> api_logout()
        {
            // Lấy tên người dùng từ claim
            var userName = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            // Lấy các thông tin khác nếu cần
            var userId = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return Content(userName);
        }


        public JsonResult api_isLogin()
        {
           bool isLogin = false;
            var id = HttpContext.Session.GetString("user_id");

            // Lấy tên người dùng từ claim
            var userName = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            // Lấy các thông tin khác nếu cần
            var userId = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;




            if ((id != null))
            {
                isLogin = true;
            }

           
            return Json(isLogin);
        }


        public object api_getUserProfile(int user_id)
        {
            var user = db.getUserProfile(user_id);
            return user;
        }







        
    }
}
