import { Component, OnInit, NgZone ,ChangeDetectorRef } from '@angular/core';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { CommonServicesService } from '../../common-services/common-services.service';
declare var bootstrap: any;
@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrl: './main-layout.component.css'
})
export class MainLayoutComponent {
  constructor(private authen: AuthenService,
    private router: Router,
    private CommonServices: CommonServicesService,
    private ngZone: NgZone,
    private changeDetected: ChangeDetectorRef) { }

  isLogin: any;
  public user = {
    user_name: ""
  }
  data: any

  ngOnInit() {
    this.CommonServices.currentUser.subscribe(user => {
        this.user = user;
        this.changeDetected.detectChanges()
        if(user){
          this.isLogin = true
        }
    });
  }
  

  logout() {
    this.authen.logout().subscribe(res => {
      this.router.navigateByUrl('login')
    })
    this.isLogin = false;
  }

  showUserProfile() {
    const offcanvasElement = document.getElementById('model_user_profile');
    const bsOffcanvas = new bootstrap.Offcanvas(offcanvasElement);
    bsOffcanvas.show();

  }
}
