import { Component } from '@angular/core';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { error } from 'node:console';
import { CommonServicesService } from '../../common-services/common-services.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  public massage = ""
  constructor(private authen: AuthenService, private router: Router, private CommonServices: CommonServicesService) { }
  loginForm: FormGroup = new FormGroup({
    code: new FormControl('443975'),
    password: new FormControl('1')
  })

  submitLogin() {
    this.authen.login(this.loginForm.value).subscribe(
      data => {
        if (data.status == true) {
          this.CommonServices.updateUser(data.user[0])
          console.log("từ server ")
          console.log(data.user)
          this.router.navigateByUrl("/")
        } else {
          this.massage = "Code or Password not correct!"
        }
      },
      error => {
        console.log(error)
      }

    )
  }

}
