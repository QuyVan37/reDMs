import { Component } from '@angular/core';

@Component({
  selector: 'app-mr',
  templateUrl: './mr.component.html',
  styleUrl: './mr.component.css'
})
export class MRComponent {

}
