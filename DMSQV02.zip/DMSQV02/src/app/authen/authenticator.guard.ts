import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthenService } from '../API-Services/authen.service';
import { map } from 'rxjs/operators';
export const authenticatorGuard: CanActivateFn = (route, state) => {

  const authService = inject(AuthenService);
  const router = inject(Router);
  return authService.isLogined().pipe(
    map(isAuthorized => {
      if (!isAuthorized) {
        router.navigate(['/login']);
        return false;
      }
      return true;
    })
  );

  };
