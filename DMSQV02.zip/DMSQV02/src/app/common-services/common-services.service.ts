import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CommonServicesService {

  constructor() { }

  private userSource = new BehaviorSubject<any>(null);
  currentUser = this.userSource.asObservable();

  updateUser(user: any) {
    this.userSource.next(user);
  }
}
